package problem1;

public class ClassB {
	ClassC classc=new ClassC();

}
