package problem1;

public class ClassA {
	public static ClassB classb=new ClassB();

}
