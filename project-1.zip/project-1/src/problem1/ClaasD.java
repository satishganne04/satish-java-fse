package problem1;

public class ClaasD {

	
	public void show() {
		System.out.println("satish");
	}
 public static void main(String[] args) {
	 
	ClassA.classb.classc.classd.show();
}

}
