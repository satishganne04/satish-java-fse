package problem1;

public class ClassC {
	ClaasD classd=new ClaasD();

}
